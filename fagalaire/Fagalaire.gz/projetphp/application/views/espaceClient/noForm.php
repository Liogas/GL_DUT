<div class="noForm">

    <i class="fas fa-frown fa-2x"></i>    
    <div class="textNoForm">
        <p>Vous n'avez toujours pas créé de formulaire</p>
        <a href="<?php echo base_url()?>index.php/formulaire/create"><p class="lienCreer">Clique ici pour en créer un</p></a>
    </div>
        <i class="fas fa-frown fa-2x"></i>

</div>