<div class="visite">
    
    <p class="textAccueil">Bienvenue sur Fagalaire !<br>Ce site vous permet de répondre à des
    formulaires créés par les personnes inscrites sur le site.</p>

    <div class="textRejoindre">
        <i class="fas fa-hand-point-down fa-3x"></i>
        <p>Rejoignez-nous</p>
        <i class="fas fa-hand-point-down fa-3x"></i>        
    </div>

<div class="corpsAccueil">

