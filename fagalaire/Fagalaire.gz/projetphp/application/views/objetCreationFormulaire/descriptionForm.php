<div class="question" class="titreDescr">
	Entrez une description :
</div>
<div class="textArea" id="descrCrea">
	<textarea name="description" placeholder="Ecrivez une description pour votre formulaire.." maxlength="4096" required></textarea>
</div>
<div class="formQuestion">