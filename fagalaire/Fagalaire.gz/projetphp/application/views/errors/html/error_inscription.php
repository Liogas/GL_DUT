<div class="erreurInscription">
	<p>Erreur, le nom d'utilisateur : <?php echo $username; ?> est déjà pris.</p>
</div>