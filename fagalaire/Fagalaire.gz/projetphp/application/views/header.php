<header>
        <h1>Fagalaire</h1>

        <form method="post" action="<?php echo base_url()?>index.php/formulaire/view/"class="rechForm">
            <input type="textarea" name="nomForm" placeholder="Entrez la clé du formulaire auquel vous souhaitez accéder.." require>
        </form>   
    </header>