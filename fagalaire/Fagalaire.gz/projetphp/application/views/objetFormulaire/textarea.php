<?php $qname = $qid."_textarea";?>
<div class="textArea">
    <textarea name="<?php echo $qname;?>" placeholder="Veuillez répondre ici.." maxlength="4096" required></textarea>
</div>