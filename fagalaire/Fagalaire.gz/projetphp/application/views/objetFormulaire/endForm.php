</div>
<div class="boutonFinal">
    <input type="submit" value="Envoyer" id="checkBtn">
    <input type="reset" value="Effacer">
</div>
    </fieldset>
</form>
<!--<script>
	$(document).ready(function() {
		$(':submit').on('click', function() {
			var is_checked = true;
			$(':checkbox').each(function(){
				if($(this).is('not:(:checked)')){
					alert($(this).val());
					is_checked = false;
				}
			});
			if(!is_checked){
				alert('un truc pas coché');
			}
    	});
	});
</script>-->