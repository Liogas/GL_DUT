<?php $qname = $qid."_text";?>
<div class="textField">
    <input type="text" name="<?php echo $qname;?>" maxlength="4096" placeholder="Veuillez répondre ici.." required>
</div>  