<?php $qname = $qid."_date";?>
<div class="date">
    <input type="date" name ="<?php echo $qname;?>" required>
</div>  